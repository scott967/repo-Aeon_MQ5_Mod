class StreamError(Exception):
    pass
