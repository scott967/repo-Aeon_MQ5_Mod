class EmptySequenceFileException(Exception):
    pass

class BadSequenceFileException(Exception):
    pass

class SequenceWriteReadEmptyException(Exception):
    pass

class SequenceWriteReadBadException(Exception):
    pass

class SequenceWriteReadUnknownException(Exception):
    pass
