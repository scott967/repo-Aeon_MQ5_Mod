# -*- coding: utf-8 -*-
import sys
import os

import xbmc, xbmcvfs
import xbmcaddon

from lib import main

lib_path = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon('script.module.youtube.dl').getAddonInfo('path')), 'lib')
sys.path.insert(0,lib_path)
main.main()
