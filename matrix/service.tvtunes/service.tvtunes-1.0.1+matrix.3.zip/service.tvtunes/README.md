![TvTunes](icon.png)

TvTunes has grown over time and is now more than a simple theme player for TV Shows. Some of the features include:
* Play themes while navigating TV Shows
* Play themes while navigating Movies
* Play themes while navigating Music Videos
* Play video themes in addition to audio themes

It is a feature rich and very configurable Add-on with numerous settings to allow you to fine-tune it to your own requirements.

More details and how to use the Add-on can be viewed on the wiki:

[Add-on:TvTunes](https://github.com/latts9923/service.tvtunes/wiki)

