INFORMATION FOR SKINNERS
------------------------

https://kodi.wiki/view/Add-on:Skin_Widgets

version 0.0.33+matrix.3:
added new video item window property PercentPlayedAsInt which provides a number string (without "%") for use in progress controls

