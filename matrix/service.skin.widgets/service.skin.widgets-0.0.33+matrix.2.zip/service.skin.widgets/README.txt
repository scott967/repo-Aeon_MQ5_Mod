INFORMATION FOR SKINNERS
------------------------

https://kodi.wiki/view/Add-on:Skin_Widgets

