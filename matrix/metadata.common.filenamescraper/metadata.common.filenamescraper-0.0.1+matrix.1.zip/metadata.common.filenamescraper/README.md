# kodi-filenameScraper
A trivial, python-based filename-only scraper for Kodi (Kodi plugin)

20 JUL 22 Updated for matrix / python 3
